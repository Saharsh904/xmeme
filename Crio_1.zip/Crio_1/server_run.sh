cd backend
<<<<<<< HEAD
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 8081
=======
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py runserver 8081
>>>>>>> 569653414b59e43ca9afb786e25e93cd1c3f493d
