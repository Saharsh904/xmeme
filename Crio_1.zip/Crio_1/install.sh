sudo apt update
<<<<<<< HEAD
sudo apt install -y python3-pip
pip3 install python
=======
sudo apt install -y python3
sudo apt install -y python3-pip
>>>>>>> 569653414b59e43ca9afb786e25e93cd1c3f493d
pip3 install django
pip3 install djangorestframework
pip3 install django-cors-headers