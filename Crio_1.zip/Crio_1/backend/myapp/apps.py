from django.apps import AppConfig


class MemesConfig(AppConfig):
    name = 'myapp'
